# Keil-Array-Visualization
Keil Array Visualization

Keil Array Visualization is a powerful keil debugging aid. 
Connect to the keil software, then read the variable or memory address, and then use the waveform display, you can choose a variety of different data types, select the size end, and export to a binary file.
Need 4.5 .net framework runtime

1.20190330, 1.4b, add and export wav function, you can manually detect updates.
 

2019.12.27 release 1.4.2  "keil数组曲线显示 KArrayV142.rar" To:2021.1.1
 

